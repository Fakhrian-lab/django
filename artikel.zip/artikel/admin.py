from django.contrib import admin
from .models import ArtikelBlog, Kategori

admin.site.register(ArtikelBlog)
admin.site.register(Kategori)
